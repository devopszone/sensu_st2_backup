"Canary" Deployment Sample Blueprint
===================================

This automation pack contains the code for a sample "Canary" continuous deployment pipeline.
It is described in great details in [Continuous Integration And Delivery, The StackStorm Way](http://stackstorm.com/2015/01/20/continuous-integration-and-delivery-the-stackstorm-way/)

Demo recording https://youtu.be/532upeN9x1w

Take this as a starting point for continious deployment, YOUR way!
