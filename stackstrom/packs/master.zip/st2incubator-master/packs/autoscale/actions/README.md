# actions

The actions folder contains action scripts and metadata files. See [Actions](http://docs.stackstorm.com/actions.html)
and [Workflows](http://docs.stackstorm.com/workflows.html) for specifics on writing actions. Note that the lib sub-folder
is always available for access for an action script.
