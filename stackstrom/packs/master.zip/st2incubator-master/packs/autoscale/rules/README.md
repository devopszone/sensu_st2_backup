# rules

The rules folder contains rules. See [Rules](http://docs.stackstorm.com/rules.html) for specifics on writing rules.
