# sensors

The sensors folder contains sensoros. See [Sensors](http://docs.stackstorm.com/sensors.html) for specifics on writing
sensors and registering TriggerTypes.
